let admin = false;
const PASSWORD = "TRRoyal653";

function login() {
  const pass = prompt("Contraseña:");
  if (pass === PASSWORD) {
    admin = true;
    alert("Modo admin activado");
  } else {
    alert("Contraseña incorrecta");
  }
}

function agregarFila() {
  if (!admin) return alert("Solo admin puede editar");

  const tabla = document.getElementById("tabla");
  const fila = tabla.insertRow();

  const c1 = fila.insertCell();
  const c2 = fila.insertCell();
  const c3 = fila.insertCell();
  const c4 = fila.insertCell();

  c1.contentEditable = true;
  c2.contentEditable = true;
  c3.contentEditable = true;

  c1.innerText = "Integrante";
  c2.innerText = "Actividad";
  c3.innerText = "0";
  c3.classList.add("rubys");

  c4.innerHTML = '<button onclick="borrarFila(this)">🗑️</button>';
}

function borrarFila(btn) {
  if (!admin) return;
  btn.parentNode.parentNode.remove();
}

function nuevaNoticia() {
  if (!admin) return alert("Solo admin puede publicar");

  const titulo = prompt("Título:");
  const contenido = prompt("Contenido:");

  const post = document.createElement("div");
  post.className = "post";
  post.innerHTML = `<h3>${titulo}</h3><p>${contenido}</p>`;
  document.getElementById("posts").appendChild(post);
}
